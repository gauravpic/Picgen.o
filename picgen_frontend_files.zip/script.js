
function generateImage() {
  const prompt = document.getElementById('prompt').value;
  const output = document.getElementById('output');

  output.innerHTML = '<p class="text-gray-400">Generating image...</p>';

  fetch('https://your-backend-api.com/generate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ prompt: prompt })
  })
  .then(res => res.json())
  .then(data => {
    output.innerHTML = '<img src="' + data.image_url + '" alt="Generated image" class="mx-auto rounded shadow mt-4"/>';
  })
  .catch(err => {
    output.innerHTML = '<p class="text-red-400">Error generating image. Please try again.</p>';
  });
}
